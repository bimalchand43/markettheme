<?php
/**
 * eCommerce Market functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package eCommerce_Market
 */

if ( ! function_exists( 'ecommerce_market_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
function ecommerce_market_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on eCommerce Market, use a find and replace
		 * to change 'ecommerce-market' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'ecommerce-market', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );
		add_image_size( 'ecommerce-market-product-carousel', 265, 230, true);
		add_image_size( 'ecommerce-market-product-tab', 50, 50, true);
		add_image_size( 'ecommerce-market-product-collection-medium', 347, 246, true);
		add_image_size( 'ecommerce-market-product-collection-large', 376, 566, true);
		add_image_size( 'ecommerce-market-product-new-arrival-large', 305, 606, true);
		add_image_size( 'ecommerce-market-product-new-arrival-small', 288, 288, true);
		add_image_size( 'ecommerce-market-product-new-arrival-medium', 488, 288, true);
		add_image_size( 'ecommerce-market-subscription', 676, 486, true);
		add_image_size( 'ecommerce-market-latest-blog', 264, 163, true);
		add_image_size( 'ecommerce-market-recent-posts', 98, 102, true);
		add_image_size( 'ecommerce-market-testimonial', 676, 511, true);
		add_image_size( 'ecommerce-market-archive', 362, 269, true);
		add_image_size( 'ecommerce-market-slider', 1400, 587, true);	



		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'ecommerce-market' ),
			'top-menu' => esc_html__( 'Top Menu', 'ecommerce-market' ),
			'social-menu' => esc_html__( 'Social Menu', 'ecommerce-market' ),
			) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'ecommerce_market_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
			) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
			) );

		// Declare WooCommerce Support
		add_theme_support( 'woocommerce' );

		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-slider' );

	}
	endif;
	add_action( 'after_setup_theme', 'ecommerce_market_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function ecommerce_market_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'ecommerce_market_content_width', 640 );
}
add_action( 'after_setup_theme', 'ecommerce_market_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function ecommerce_market_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'ecommerce-market' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'ecommerce-market' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
		) );

	register_sidebar( array(
		'name'          => esc_html__( 'Home Page Section', 'ecommerce-market' ),
		'id'            => 'home-page-section-sidebar',
		'description'   => esc_html__( 'Add widgets here.', 'ecommerce-market' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => sprintf( esc_html__( 'Footer %d', 'ecommerce-market' ), 1 ),
		'id'            => 'footer-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title"><span>',
		'after_title'   => '</h2></span>',
	) );
	register_sidebar( array(
		'name'          => sprintf( esc_html__( 'Footer %d', 'ecommerce-market' ), 2 ),
		'id'            => 'footer-2',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title"><span>',
		'after_title'   => '</h2></span>',
	) );
	register_sidebar( array(
		'name'          => sprintf( esc_html__( 'Footer %d', 'ecommerce-market' ), 3 ),
		'id'            => 'footer-3',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title"><span>',
		'after_title'   => '</h2></span>',
	) );	
	register_sidebar( array(
		'name'          => sprintf( esc_html__( 'Footer %d', 'ecommerce-market' ), 4 ),
		'id'            => 'footer-4',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title"><span>',
		'after_title'   => '</h2></span>',
	) );	

	if ( ecommerce_market_is_woocommerce_active() ) : 
		register_sidebar( array(
			'name'          => esc_html__( 'Shop Sidebar', 'ecommerce-market' ),
			'id'            => 'sidebar-shop',
			'description'   => esc_html__( 'Add widgets here.', 'ecommerce-market' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
			) );
	endif;

}
add_action( 'widgets_init', 'ecommerce_market_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function ecommerce_market_scripts() {
	// Load fontawesome
	wp_enqueue_style( 'font-awesome', get_template_directory_uri().'/assest/css/font-awesome.min.css', array(), '4.4.0' );

	// Animation
	wp_enqueue_style( 'animation', get_template_directory_uri().'/assest/css/animation.css', array(), '1.0.0' );	

	// Owl Carousel Assets
	wp_enqueue_style( 'owl-carousel', get_template_directory_uri().'/assest/css/owl.carousel.css', array(), 'v2.2.0' );	

	// Owl Theme meanmenu
	wp_enqueue_style( 'owl-theme', get_template_directory_uri().'/assest/css/owl.theme.css', array(), 'v2.2.0' );

	//meanmenu
	wp_enqueue_style( 'select2', get_template_directory_uri().'/assest/css/select2.min.css', array(), '2.0.7' );	

	//meanmenu
	wp_enqueue_style( 'meanmenu', get_template_directory_uri().'/assest/css/meanmenu.css', array(), '2.0.7' );

	wp_enqueue_style( 'ecommerce-market-style', get_stylesheet_uri() );
	add_editor_style( 'ecommerce-market-style', get_stylesheet_uri());

	//responsive 
	wp_enqueue_style( 'ecommerce-market-responsive', get_template_directory_uri().'/assest/css/responsive.css', array(), '20170905' );	

	//owl carousel
	wp_enqueue_script( 'jquery-owl-carousel', get_template_directory_uri() . '/assest/js/owl.carousel.js', array('jquery'), 'v2.2.1', true );

	//isotope-docs 
	wp_enqueue_script( 'jquery-isotope', get_template_directory_uri() . '/assest/js/isotope.pkgd.js', array('jquery'), 'v2.0.8', true );

	//stellar
	wp_enqueue_script( 'jquery-stellar', get_template_directory_uri() . '/assest/js/stellar.js', array('jquery'), 'v0.6.2', true );

	//select2
	wp_enqueue_script( 'jquery-select2', get_template_directory_uri() . '/assest/js/select2.min.js', array('jquery'), '4.0.3 ', true );

	//jquery-meanmenu
	wp_enqueue_script( 'jquery-meanmenu', get_template_directory_uri() . '/assest/js/jquery.meanmenu.js', array('jquery'), 'v2.0.8', true );

	//portfolio
	wp_enqueue_script( 'jquery-portfolio', get_template_directory_uri() . '/assest/js/portfolio.js', array('jquery'), '20170905', true );

	//waypoints
	wp_enqueue_script( 'jquery-waypoints', 'https://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js', array('jquery'), '', true );

	wp_enqueue_script( 'ecommerce-market-navigation', get_template_directory_uri() . '/assest/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'ecommerce-market-skip-link-focus-fix', get_template_directory_uri() . '/assest/js/skip-link-focus-fix.js', array(), '20151215', true );

	wp_enqueue_script( 'jquery-ResizeSensor-js', get_template_directory_uri() . '/assest/js/ResizeSensor.js', array(), '20151215', true );
	
	wp_enqueue_script( 'jquery-theia-sticky-sidebar-js', get_template_directory_uri() . '/assest/js/theia-sticky-sidebar.js', array(), '20151215', true );

	//custom
	wp_enqueue_script( 'ecommerce-market-custom', get_template_directory_uri() . '/assest/js/custom.js', array(), '20170905', true );	

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ecommerce_market_scripts' );

/**
 * Load init.
 */
require_once trailingslashit( get_template_directory() ) . 'inc/init.php';
 // remove_role( 'test' );
add_role( 'test', 'Test Role', array(
    'read' => true, // True allows that capability
    'edit_posts' => true, // Allows user to edit their own posts
    'publish_posts'=>false, //Allows the user to publish, otherwise posts stays in draft mode
    'edit_published_posts'=>true,
    'upload_files'=>true,
    'delete_published_posts'=>true,

    'edit_products' => true, // Allows user to edit their own product
    'publish_products'=>false, //Allows the user to publish, otherwise product stays in draft mode
    'edit_published_products'=>true,
    'upload_files'=>true,
    'delete_published_products'=>true,

));

add_action('pre_get_posts', 'filter_posts_list');
function filter_posts_list($query)
{
    //$pagenow holds the name of the current page being viewed
	global $pagenow;

    //$current_user uses the get_currentuserinfo() method to get the currently logged in user's data
	global $current_user;


        //Shouldn't happen for the admin, but for any role with the edit_posts capability and only on the posts list page, that is edit.php
	if(!current_user_can('administrator') && current_user_can('edit_posts') && ('edit.php' == $pagenow))
	{
        //global $query's set() method for setting the author as the current user's id
		$query->set('author', $current_user->ID); 
	}
}

add_action('pre_get_product', 'filter_posts_list1');
function filter_posts_list1($query)
{
    //$pagenow holds the name of the current page being viewed
	global $pagenow;

    //$current_user uses the get_currentuserinfo() method to get the currently logged in user's data
	global $current_user;
	get_currentuserinfo();

        //Shouldn't happen for the admin, but for any role with the edit_posts capability and only on the posts list page, that is edit.php
	if(!current_user_can('administrator') && current_user_can('edit_posts') && ('edit.php??post_type=product' == $pagenow))
	{
        //global $query's set() method for setting the author as the current user's id
		$query->set('author', $current_user->ID); 
		
	}
}
add_filter( 'ajax_query_attachments_args', 'show_users_own_attachments', 1, 1 );
function show_users_own_attachments( $query ) 
{
 $id = get_current_user_id();
 if( !current_user_can('manage_options') ){
 	$query['author'] = $id;
 }
 if( !current_user_can('administrator') ){
 	$query['author'] = $id;
 }
 
 return $query;
}